
const express = require('express');
const fs = require('fs');
const path = require('path');
const cors = require('cors');
const morgan = require('morgan');
const session = require('express-session');
require('dotenv').config();

let fetchFn = global.fetch;
if (!fetchFn) { fetchFn = (...args) => import('node-fetch').then(({default: fetch}) => fetch(...args)); }
const fetch = fetchFn;

const app = express();
const PORT = process.env.PORT || 5058;
const CRD_SERVER_URL = process.env.CRD_SERVER_URL || "https://crd.davinci.hl7.org/r4";

app.use(cors());
app.use(express.json({limit: '8mb'}));
app.use(morgan('dev'));
app.use(express.static(path.join(__dirname, 'public')));
// SMART session support
app.use(
  session({
    secret: "smart-secret",
    resave: false,
    saveUninitialized: true,
    cookie: {
      sameSite: "lax",
      secure: false   // ✅ REQUIRED for localhost
    }
  })
);

const trimSlashes = (s='') => s.replace(/\/+$/,''); // ✅ forward slashes only

function readJsonFile(p){ return JSON.parse(fs.readFileSync(p,'utf8')); }
function bundleWrap(resources){
  const entries=(resources||[]).filter(Boolean).map(r=>({fullUrl: r.id?`${r.resourceType}/${r.id}`:undefined, resource:r}));
  return {resourceType:"Bundle", type:"searchset", total: entries.length, entry: entries};
}
function keyCanon(s){ return (s||'').toLowerCase().replace(/[^a-z]/g,''); }
function inferBundleForKey(key, payload){
  const canon = keyCanon(key);
  const ctx = payload.context || {};
  const draft = ctx.draftOrders?.entry?.map(e=>e.resource) || [];
  const find = (t)=> draft.find(r=>r && r.resourceType===t);
  const patientId = ctx.patientId || 'demo-patient';
  const patient = {resourceType:"Patient", id:patientId, name:[{text:"Test Patient"}]};
  if(canon.includes('servicerequest')){
    const sr = find('ServiceRequest');
    const role={resourceType:"PractitionerRole",id:"prr1",practitioner:{reference:"Practitioner/p1"},organization:{reference:"Organization/o1"}};
    const prac={resourceType:"Practitioner",id:"p1",name:[{text:"Alice Smith, MD"}]};
    const org={resourceType:"Organization",id:"o1",name:"Good Health Clinic"};
    return bundleWrap([sr, patient, role, prac, org].filter(Boolean));
  }
  if(canon.includes('devicerequest')){
    const dr = find('DeviceRequest');
    const device={resourceType:"Device",id:"dev1",type: dr?.codeCodeableConcept};
    const role={resourceType:"PractitionerRole",id:"prr1",practitioner:{reference:"Practitioner/p1"},organization:{reference:"Organization/o1"}};
    const prac={resourceType:"Practitioner",id:"p1",name:[{text:"Alice Smith, MD"}]};
    const org={resourceType:"Organization",id:"o1",name:"Good Health Clinic"};
    return bundleWrap([dr, device, patient, role, prac, org].filter(Boolean));
  }
  if(canon.includes('medicationrequest')){
    const mr = find('MedicationRequest');
    const role={resourceType:"PractitionerRole",id:"prr1",practitioner:{reference:"Practitioner/p1"},organization:{reference:"Organization/o1"}};
    const prac={resourceType:"Practitioner",id:"p1",name:[{text:"Alice Smith, MD"}]};
    const org={resourceType:"Organization",id:"o1",name:"Good Health Clinic"};
    return bundleWrap([mr, patient, role, prac, org].filter(Boolean));
  }
  if(canon.includes('coverage')){
    const coverage={resourceType:"Coverage",id:"cov1",status:"active",beneficiary:{reference:`Patient/${patientId}`},payor:[{reference:"Organization/payer1"}]};
    const payer={resourceType:"Organization",id:"payer1",name:"Example Health Plan"};
    return bundleWrap([coverage, patient, payer]);
  }
  return bundleWrap([patient]);
}
function alignPrefetchToDiscovery(serviceMeta, payload, buildPrefetch){
  if(!serviceMeta || typeof serviceMeta!=='object') return payload;
  const preKeys = Object.keys(serviceMeta.prefetch || {});
  if(!preKeys.length) return payload;
  payload.prefetch = Object.assign({}, payload.prefetch || {});
  preKeys.forEach((k)=>{
    if(payload.prefetch[k] == null){
      payload.prefetch[k] = buildPrefetch ? inferBundleForKey(k, payload) : null;
    }
  });
  return payload;
}
async function fetchServiceMetaIfNeeded(url){
  try{
    const base = url.replace(/\/cds-services\/.*/, '');
    const discUrls = [`${base}/.well-known/cds-services`, `${base}/cds-services`];
    for(const d of discUrls){
      try{
        const r=await fetch(d,{headers:{'Accept':'application/json'}});
        const j=await r.json();
        const svcs=j.services || j['cds-services'] || [];
        const id=url.split('/').pop();
        const m=svcs.find(s=>s.id===id);
        if(m) return m;
      }catch{}
    }
  }catch{}
  return null;
}
// ================================
// DTR AUTO-FILL BUILDER (PER FORM)
// ================================
function buildPrefill(questionnaireId, crd) {
  const ctx = crd.context || {};
  const prefetch = crd.prefetch || {};

  const sr =
    prefetch.serviceRequestBundle?.entry
      ?.find(e => e.resource.resourceType === "ServiceRequest")
      ?.resource;

  const provider =
    prefetch.serviceRequestBundle?.entry
      ?.find(e => e.resource.resourceType === "Practitioner")
      ?.resource;

  const providerGiven = Array.isArray(provider?.name?.[0]?.given)
    ? provider.name[0].given.join(" ")
    : provider?.name?.[0]?.given || "";

  const providerFamily = provider?.name?.[0]?.family || "";

  const providerName = [providerGiven, providerFamily]
    .filter(Boolean)
    .join(" ");

  const diagnoses =
    sr?.reasonCode
      ?.map(r => r.text || r.coding?.[0]?.display)
      ?.join(", ") || "";

  const orders =
    sr?.code?.coding
      ?.map(c => `${c.code} ${c.display || ""}`)
      ?.join(", ") || "";

  switch (questionnaireId) {

    case "order-form":
      return {
        "1": ctx.patientId || "",
        "PND": providerName,
        "3": diagnoses,
        "4": orders,
        "6": "Yes",
        "7": "Yes",
        "8": "No",
        "10": providerName
      };

    case "face-to-face":
      return {
        "patient": ctx.patientId || "",
        "encounter-provider": providerName,
        "clinical-findings": diagnoses,
        "encounter-date": new Date().toISOString().split("T")[0]
      };

    case "plan-of-care":
      return {
        "ordering-physician": providerName,
        "treatment-plan": orders,
        "medical-necessity": diagnoses,
        "certification-date": new Date().toISOString().split("T")[0]
      };

    default:
      return {};
  }
}

app.get('/api/config', (_req,res)=> res.json({ defaultServerUrl: CRD_SERVER_URL }));

app.get('/api/requests', (_req,res)=>{
  const dir = path.join(__dirname,'requests');
  if(!fs.existsSync(dir)) fs.mkdirSync(dir,{recursive:true});
  const files = fs.readdirSync(dir).filter(f=>f.endsWith('.json')).map(name=>({name}));
  res.json({ files });
});

app.get('/api/requests/:name', (req,res)=>{
  const filePath = path.join(__dirname,'requests',req.params.name);
  if(!fs.existsSync(filePath)) return res.status(404).json({error:'File not found'});
  try{ res.json(readJsonFile(filePath)); } catch(e){ res.status(400).json({error:e.message}); }
});

app.get('/api/discovery', async (req,res)=>{
  const base = trimSlashes((req.query.serverUrl||CRD_SERVER_URL));
  const attempts=[`${base}/.well-known/cds-services`, `${base}/cds-services`];
  let lastErr=null;
  for(const url of attempts){
    try{
      const r=await fetch(url,{headers:{'Accept':'application/json'}});
      const j=await r.json();
      if(r.ok && (j.services || j['cds-services'])) return res.json({url, data:j});
      lastErr = `HTTP ${r.status}`;
    }catch(e){ lastErr=e.message; }
  }
  res.status(502).json({ error:`Discovery failed for ${base}`, tried: attempts, lastErr });
});

app.post('/api/invoke', async (req,res)=>{
  try{
    const { filename, serviceId, serviceIdOverride, serverUrl, buildPrefetch, serviceMeta, authToken, payload: payloadIn } = req.body || {};
    const base = trimSlashes((serverUrl||CRD_SERVER_URL));
    const chosen=(serviceIdOverride && serviceIdOverride.trim()) || serviceId;
    if(!chosen) return res.status(400).json({error:"serviceId (or full URL) is required"});
    const url = /^https?:\/\//i.test(chosen) ? chosen : `${base}/cds-services/${chosen}`;

    let payload=null;
    if(filename){
      const fp=path.join(__dirname,'requests',filename);
      if(!fs.existsSync(fp)) return res.status(400).json({error:`Request file not found: ${filename}`});
      payload = readJsonFile(fp);
    } else if (payloadIn){ payload = payloadIn; }
    else { return res.status(400).json({error:"Provide either filename or payload"}); }

    if(payload && Object.prototype.hasOwnProperty.call(payload,'fhirServer')) delete payload.fhirServer;
    if(!payload.user && payload?.context?.userId) payload.user = payload.context.userId;

    let meta = serviceMeta;
    if(!meta && /^https?:\/\//i.test(chosen)) meta = await fetchServiceMetaIfNeeded(url);
    if(meta){ payload = alignPrefetchToDiscovery(meta, payload, !!buildPrefetch); }
    else if(buildPrefetch){
      const wanted=['serviceRequestBundle','deviceRequestBundle','medicationRequestBundle','coverageBundle'];
      payload.prefetch = Object.assign({}, payload.prefetch || {});
      for(const k of wanted){
        if(payload.prefetch[k] == null){
          payload.prefetch[k] = inferBundleForKey(k, payload) || null;
        }
      }
    }

    const headers={'Content-Type':'application/json','Accept':'application/json'};
    if(authToken) headers['Authorization'] = `Bearer ${authToken}`;
    // ✅ STORE CRD REQUEST FOR DTR AUTO-FILL
    req.session.crdRequestPayload = payload;

    const r=await fetch(url,{method:'POST', headers, body: JSON.stringify(payload)});
    const text=await r.text(); let data=null; try{ data=JSON.parse(text); }catch{ data={raw:text}; }
    // 1️⃣ LOG CRD RESPONSE
    console.log("===== CRD RESPONSE =====");
    console.log(JSON.stringify(data, null, 2));
    console.log("========================");

    // 2️⃣ SAVE CRD RESPONSE TO FILE
    const responsesDir = path.join(__dirname, 'responses');
    if (!fs.existsSync(responsesDir)) {
    fs.mkdirSync(responsesDir, { recursive: true });
    }

    const ts = new Date().toISOString().replace(/[:.]/g,'-');
    fs.writeFileSync(
    path.join(responsesDir, `crd-response-${ts}.json`),
    JSON.stringify(data, null, 2)
    );

    // 3️⃣ EXTRACT PAS LINK (optional but recommended)
    const pasLinks =
    data?.cards
        ?.flatMap(card => card.links || [])
        ?.filter(l => l.label?.toLowerCase().includes('prior auth'));
    const safePasLinks = Array.isArray(pasLinks) ? pasLinks : [];

    console.log("PAS LINKS:", pasLinks);
    if (!safePasLinks.length) {
    console.warn("⚠️ No PAS link returned by CRD");
  }
    // ✅ STORE PAS ENDPOINT FOR LATER PAS SUBMISSION
    if (pasLinks && pasLinks.length > 0) {
      req.session.pasEndpoint = pasLinks[0].url;
      console.log("Stored PAS endpoint:", req.session.pasEndpoint);
    }
    if (!pasLinks || pasLinks.length === 0) {
      console.warn("⚠️ CRD returned NO PAS link for this service");
    }

    // 4️⃣ EXTRACT SMART LINK (DTR)
    const smartLinks =
      data?.cards
        ?.flatMap(card => card.links || [])
        ?.filter(l => l.type === "smart");

    // ✅ Deduplicate by appContext (BEST key)
    const uniqueSmartLinks = Array.from(
      new Map(
        smartLinks.map(l => [l.appContext, l])
      ).values()
    );


    if (smartLinks) {
        const aidboxBase = "https://uofkdiltdb.edge.aidbox.app";

        const smartLaunchLinks = uniqueSmartLinks.map(l => ({
        label: l.label,
        launchUrl:
            `http://localhost:${PORT}/launch` +
            `?iss=${encodeURIComponent(aidboxBase)}` +
            `&launch=${encodeURIComponent(
              l.appContext + "&pas=" + (pasLinks[0]?.url || "")
            )}`
        }));

        return res.json({
          ...data,                 // full CRD response
          smartLaunchLinks,        // ✅ ALL THREE
          hasDTR: smartLaunchLinks.length > 0
        });
        }

    res.status(r.status).json({ url, status: r.status, ok: r.ok, data });
  }catch(e){ res.status(500).json({error:e.message}); }
});

app.get('/', (_req,res)=> res.sendFile(path.join(__dirname, 'public', 'index.html')));
// ================================
// DTR BRIDGE (NEW TAB SAFE)
// ================================
app.get("/dtr-bridge", (req, res) => {
  const { url } = req.query;

  if (!url) {
    return res.status(400).send("Missing url parameter");
  }

  res.send(`
    <html>
      <head>
        <title>Launching DTR...</title>
      </head>
      <body>
        <script>
          window.location.href = "${decodeURIComponent(url)}";
        </script>
      </body>
    </html>
  `);
});


// ================================
// SMART ON FHIR: LAUNCH
// ================================
app.get("/launch", (req, res) => {
  console.log("LAUNCH HIT");
  console.log("ISS:", req.query.iss);
  console.log("LAUNCH CONTEXT:", req.query.launch);

  if (!req.query.iss) {
    return res.status(400).send("Missing iss parameter");
  }

  req.session.iss = req.query.iss;
  req.session.launch = req.query.launch;

  const authorizeUrl =
    `${req.session.iss}/auth/authorize` +
    `?response_type=code` +
    `&client_id=smart-app1` +
    `&redirect_uri=${encodeURIComponent("http://localhost:5058/callback")}` +
    `&scope=${encodeURIComponent(
      "openid profile fhirUser launch launch/patient patient/Patient.read patient/Coverage.read user/Questionnaire.read"
    )}` +
    `&aud=${encodeURIComponent(req.session.iss)}` +
    `&state=abc123`;

  res.redirect(authorizeUrl);
});

// ================================
// SMART ON FHIR: CALLBACK
// ================================
app.get("/callback", async (req, res) => {
  console.log("CALLBACK HIT");
  console.log("AUTH CODE:", req.query.code);
  console.log("ISS FROM SESSION:", req.session.iss);
  console.log("SESSION AT CALLBACK:", req.session);

  if (!req.session.iss) {
    return res.status(400).json({
      error: "SMART launch context missing (iss not found). You must start from /launch"
    });
  }

  const tokenResp = await fetch(`${req.session.iss}/auth/token`, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      grant_type: "authorization_code",
      code: req.query.code,
      redirect_uri: `http://localhost:5058/callback`,
      client_id: "smart-app1",
      client_secret: "smart-secret"
    })
  });

  const token = await tokenResp.json();
  console.log("TOKEN RESPONSE:", token);

  req.session.token = token;
  // ✅ Extract patient id safely
  if (!token.patient && token.id_token) {
    const payload = JSON.parse(
      Buffer.from(token.id_token.split('.')[1], 'base64').toString()
    );
    token.patient = payload.patient;
  }

  console.log("Resolved patientId:", token.patient);
  req.session.save(() => res.redirect("/app"));
});

// ================================
  // DTR FORM SUBMISSION
  // ================================
  app.post(
    "/submit-dtr",
    express.urlencoded({ extended: true }),
    (req, res) => {

      const answers = req.body;
      const questionnaireResponse = {
        resourceType: "QuestionnaireResponse",
        status: "completed",
        questionnaire: req.session.questionnaireUrl,
        subject: {
          reference: `Patient/${req.session.token.patient}`
        },
        item: Object.entries(answers).map(([linkId, value]) => ({
          linkId,
          answer: [{ valueString: value }]
        }))
      };

      // ✅ Save QR for PAS
      req.session.questionnaireResponse = questionnaireResponse;

      res.redirect("/submit-pas");
    }
  );

  // ================================
  // PAS SUBMISSION
  // ================================
  app.get("/submit-pas", async (req, res) => {
    const token = req.session.token?.access_token;
    const pasEndpoint = req.session.pasEndpoint;

    if (!token) return res.status(401).send("Missing SMART token");
    if (!pasEndpoint) return res.status(400).send("PAS endpoint not available");

    const claim = {
      resourceType: "Claim",
      status: "active",
      use: "preauthorization",
      type: {
        coding: [{
          system: "http://terminology.hl7.org/CodeSystem/claim-type",
          code: "professional"
        }]
      },
      patient: { reference: `Patient/${req.session.token.patient}` },
      provider: { reference: "Practitioner/p1" },
      insurer: { reference: "Organization/payer1" },
      insurance: [{
        sequence: 1,
        focal: true,
        coverage: { reference: "Coverage/cov1" }
      }],
      item: [{
        sequence: 1,
        productOrService: {
          coding: [{
            system: "http://www.ama-assn.org/go/cpt",
            code: "70551"
          }]
        }
      }],
      supportingInfo: [{
        sequence: 1,
        category: {
          coding: [{
            system: "http://hl7.org/fhir/claiminformationcategory",
            code: "questionnaire"
          }]
        },
        valueReference: { reference: "#qr1" }
      }],
      contained: [{
        ...req.session.questionnaireResponse,
        id: "qr1"
      }]
    };

    const response = await fetch(pasEndpoint, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/fhir+json"
      },
      body: JSON.stringify(claim)
    });

    const result = await response.json();
    res.json(result);
  });

// ================================
// SMART ON FHIR: APP (DTR)
// ================================
app.get("/app", async (req, res) => {
  if (!req.session.token?.access_token) {
    return res.status(401).send("No SMART token");
  }
  if (!req.session.iss || !req.session.launch) {
  return res
    .status(400)
    .send("SMART launch missing. Please start from CRD Invoke → Launch.");
  }
  // ================================
  // ✅ EXTRACT SMART LAUNCH PARAMETERS
  // ================================
  const launchParams = new URLSearchParams(
    decodeURIComponent(req.session.launch)
  );

  // ✅ DEFINE questionnaireUrl (THIS WAS MISSING)
  const questionnaireUrl = launchParams.get("questionnaire");
  const questionnaireId = questionnaireUrl.split("/").pop();
  console.log("QUESTIONNAIRE ID:", questionnaireId);

  if (!questionnaireUrl) {
    return res.status(400).send("Questionnaire URL missing from launch context");
  }

  // Save for submit-dtr
  req.session.questionnaireUrl = questionnaireUrl;

  // ================================
  // ✅ FETCH QUESTIONNAIRE (REQUIRED)
  // ================================
  const q = await fetch(questionnaireUrl, {
    headers: {
      Authorization: `Bearer ${req.session.token.access_token}`
    }
  });

  if (!q.ok) {
    return res
      .status(q.status)
      .send(`Failed to fetch Questionnaire: ${q.statusText}`);
  }

  // ✅ THIS DEFINES `questionnaire`
  const questionnaire = await q.json();

  // ================================
  // ✅ GET PATIENT FROM CRD PREFETCH BUNDLES
  // ================================
  const crdPayload = req.session.crdRequestPayload || {};
  const crdPrefetch = crdPayload.prefetch || {};

  let patient = null;

  // 1️⃣ Look inside serviceRequestBundle
  patient =
    crdPrefetch.serviceRequestBundle?.entry
      ?.find(e => e.resource.resourceType === "Patient")
      ?.resource

  // 2️⃣ Fallback: look inside coverageBundle
  || crdPrefetch.coverageBundle?.entry
      ?.find(e => e.resource.resourceType === "Patient")
      ?.resource;

  // 3️⃣ Final fallback: SMART FHIR read
  if (!patient) {
    const resolvedPatientId =
      req.session.token.patient ||
      crdPayload.context?.patientId;

    console.log("Fetching Patient from FHIR:", resolvedPatientId);

    if (resolvedPatientId) {
      const patientRes = await fetch(
        `${req.session.iss}/Patient/${resolvedPatientId}`,
        {
          headers: {
            Authorization: `Bearer ${req.session.token.access_token}`
          }
        }
      );

      if (patientRes.ok) {
        patient = await patientRes.json();
      }
    }
  }

  console.log("FINAL PATIENT OBJECT:", JSON.stringify(patient, null, 2));

  // ================================
  // ✅ EXTRACT PATIENT DETAILS
  // ================================
  const givenNames = Array.isArray(patient?.name?.[0]?.given)
    ? patient.name[0].given.join(" ")
    : patient?.name?.[0]?.given || "";

  const familyName = patient?.name?.[0]?.family || "";

  const patientName = [givenNames, familyName]
    .filter(Boolean)
    .join(" ");

  const mrn =
  Array.isArray(patient.identifier)
    ? patient.identifier.find(
        id => id.type?.coding?.[0]?.code === "MR"
      )?.value || ""
    : "";
  const phone =
  Array.isArray(patient.telecom)
    ? patient.telecom.find(t => t.system === "phone")?.value || ""
    : "";

  const patientInfo = [
    patientName,
    mrn && `MRN: ${mrn}`,
    phone && `Phone: ${phone}`
  ].filter(Boolean).join(" | ");

  console.log("PATIENT INFO STRING:", patientInfo);
  // ================================
  // ✅ AUTO-FILL FROM CRD REQUEST JSON
  // ================================

  const crd = req.session.crdRequestPayload || {};
  const crdCtx = crd.context || {};
  const prefetch = crd.prefetch || {};

  // PatientId MUST come from CRD (not SMART)
  const patientId = crdCtx.patientId || "";

  // ServiceRequest
  const serviceRequest =
    prefetch.serviceRequestBundle?.entry
      ?.find(e => e.resource.resourceType === "ServiceRequest")
      ?.resource;

  // Diagnosis
  const diagnoses =
    serviceRequest?.reasonCode
      ?.map(rc => rc.text || rc.coding?.[0]?.display)
      ?.join(", ") || "";

  // Orders
  const orders =
    serviceRequest?.code?.coding
      ?.map(c => `${c.code} ${c.display || ""}`)
      ?.join(", ") || "";

  // Provider
  const provider =
    prefetch.serviceRequestBundle?.entry
      ?.find(e => e.resource.resourceType === "Practitioner")
      ?.resource;

  const providerName =
    provider?.name?.[0]
      ? `${provider.name[0].given?.join(" ")} ${provider.name[0].family}`
      : "";

  // ================================
  // ✅ BUILD PREFILL MAP (ORDER MATTERS)
  // ================================
  const prefill = {};

  // 🔒 Fallback: always populate first item as Patient Info
  if (questionnaire.item?.length) {
    prefill[questionnaire.item[0].linkId] = patientInfo;
  }

  questionnaire.item.forEach(item => {
    const label = (item.text || "").toLowerCase();

    // Patient
    if (
      label.includes("patient") ||
      label.includes("member") ||
      label.includes("beneficiary")
    ) {
      prefill[item.linkId] = patientInfo;
    }

    // Provider
    if (
      label.includes("provider") ||
      label.includes("physician") ||
      label.includes("ordering")
    ) {
      prefill[item.linkId] = providerName;
    }

    // Diagnosis
    if (label.includes("diagnos")) {
      prefill[item.linkId] = diagnoses;
    }

    // Orders
    if (
      label.includes("order") ||
      label.includes("treatment") ||
      label.includes("service")
    ) {
      prefill[item.linkId] = orders;
    }

    // Therapy defaults
    if (label.includes("physical therapy")) {
      prefill[item.linkId] = "Yes";
    }
    if (label.includes("occupational therapy")) {
      prefill[item.linkId] = "Yes";
    }
    if (label.includes("speech")) {
      prefill[item.linkId] = "No";
    }
  });

  console.log("AUTO-FILL MAP (DYNAMIC):", prefill);
  console.log(
  "CRD PAYLOAD AVAILABLE:",
  JSON.stringify(req.session.crdRequestPayload, null, 2)
  );

  const questionnaireResponse = {
    resourceType: "QuestionnaireResponse",
    questionnaire: questionnaireUrl,
    status: "in-progress",
    subject: { reference: `Patient/${req.session.token.patient}` },
    item: questionnaire.item.map(q => ({
      linkId: q.linkId,
      answer: prefill[q.linkId]
        ? [{ valueString: prefill[q.linkId] }]
        : []
    }))
  };

  req.session.prefilledQR = questionnaireResponse;


  // RENDER HTML FORM
  let html = `
    <html>
    <head>
      <title>DTR Questionnaire</title>
      <style>
        body { font-family: Arial; padding: 20px }
        label { font-weight: bold }
        input { margin-bottom: 10px; display: block }
      </style>
    </head>
    <body>
      <h2>${questionnaire.title || "DTR Form"}</h2>
      <form method="POST" action="/submit-dtr">
  `;

  const escape = v =>
    String(v || "").replace(/"/g, "&quot;");

  questionnaire.item?.forEach(item => {
    html += `
      <label>${item.text || item.linkId}</label>
      <input
      type="text"
      name="${item.linkId}"
      value="${prefill[item.linkId] || ''}"
    />
    `;
  });
  /*
  // 🔍 DEBUG: see actual Questionnaire linkIds
  questionnaire.item?.forEach(item => {
    console.log("LINKID =", item.linkId, "| LABEL =", item.text);
  });
  */
  html += `
      <button type="submit">Submit</button>
      </form>
    </body>
    </html>
  `;

  res.send(html);
});

app.get("/api/token", (req, res) => {
  if (!req.session.token) {
    return res.status(404).json({ error: "No SMART token in session" });
  }

  res.json({
    access_token: req.session.token.access_token,
    id_token: req.session.token.id_token,
    token_type: req.session.token.token_type,
    scope: req.session.token.scope,
    patient: req.session.token.patient
  });
});

app.listen(PORT, ()=>{
  console.log(`CRD Client listening on http://localhost:${PORT}`);
  console.log(`Default CRD base: ${CRD_SERVER_URL}`);
});
