/**
 * server.js
 * ---------------------------------------
 * Node.js CRD Client using Aidbox as EHR
 * ---------------------------------------
 */

import express from "express";
import fetch from "node-fetch";
import dotenv from "dotenv";
import crypto from "crypto";

dotenv.config();

const app = express();
const PORT = 5059;

/* ===============================
   CONFIG
================================ */
const AIDBOX_BASE = process.env.AIDBOX_BASE; // https://uofkdiltdb.edge.aidbox.app
const AIDBOX_TOKEN = process.env.AIDBOX_TOKEN;
const CRD_URL =
  "https://crd.davinci.hl7.org/r4/cds-services/order-sign-crd";

/* ===============================
   MIDDLEWARE
================================ */
app.use(express.json({ limit: "5mb" }));

/* ===============================
   AIDBOX FETCH HELPER
================================ */
async function fetchFromAidbox(resourceType, id) {
  const res = await fetch(
    `${AIDBOX_BASE}/fhir/${resourceType}/${id}`,
    {
      headers: {
        Authorization: `Bearer ${AIDBOX_TOKEN}`,
        Accept: "application/json"
      }
    }
  );

  if (!res.ok) {
    const txt = await res.text();
    throw new Error(
      `Aidbox error fetching ${resourceType}/${id}: ${txt}`
    );
  }

  return res.json();
}

/* ===============================
   CRD INVOKE ENDPOINT
================================ */
app.post("/api/invoke", async (req, res) => {
  try {
    /**
     * STEP 1: Fetch REAL EHR data from Aidbox
     */
    const patient = await fetchFromAidbox("Patient", "pat-001");
    const coverage = await fetchFromAidbox("Coverage", "cov-001");
    const serviceRequest = await fetchFromAidbox(
      "ServiceRequest",
      "sr-001"
    );

    /**
     * STEP 2: Build CDS Hooks payload (VALID)
     */
    const crdPayload = {
      hook: "order-sign",
      hookInstance: crypto.randomUUID(),
      context: {
        patientId: patient.id,
        draftOrders: {
          resourceType: "Bundle",
          type: "collection",
          entry: [
            {
              resource: serviceRequest
            }
          ]
        }
      },
      prefetch: {
        patient: patient,
        coverage: coverage
      }
    };

    /**
     * STEP 3: Call CRD
     */
    const crdResp = await fetch(CRD_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json"
      },
      body: JSON.stringify(crdPayload)
    });

    const crdText = await crdResp.text();

    let crdData;
    try {
      crdData = JSON.parse(crdText);
    } catch {
      return res.status(502).json({
        error: "Invalid CRD response",
        raw: crdText
      });
    }

    /**
     * STEP 4: Return FULL CRD cards
     */
    return res.json(crdData);

  } catch (err) {
    console.error("ERROR:", err.message);
    return res.status(500).json({
      error: err.message
    });
  }
});

/* ===============================
   SERVER START
================================ */
app.listen(PORT, () => {
  console.log(`CRD server running on http://localhost:${PORT}`);
  console.log(`Using Aidbox: ${AIDBOX_BASE}`);
});
